Decky Plugin Installer

1. Extract this archive onto the SteamOS Desktop, so that the
   DeckyPluginInstaller folder sits directly on the Desktop.
2. Double-click "Install SDH-Ludusavi Decky Plugin".
3. Approve the installation and administrator-authentication dialogs.

No Konsole window is required.

The installer log is written to:
  /home/deck/Desktop/Decky Plugin Installer.log
